class Fruit{
  constructor(type){//valid types: moving, still
    this.pos = createVector(fruitSpawn[0],fruitSpawn[1])
  }
}