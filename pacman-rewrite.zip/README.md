# pacman-js-rewrite
A rewrite of my previous iteration of my pacman implementation in js


find it hosted on replit: https://replit.com/@SeamusDonahue/pacman-rewrite?v=1
